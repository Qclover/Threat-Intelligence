# -*- coding: utf-8 -*-
import scrapy
import os
import time
#from urlCrawl.items import UrlcrawlItem
from urlCrawl.items import WhoisItem
from urlCrawl.items import DnsItem
from urlCrawl.items import MalwareItem
from urlCrawl.items import SubnetItem
from urlCrawl.items import TimelineItem
from urlCrawl.items import IpinfoItem
import json
import jsonpath
from scrapy.conf import settings

class UrlspiderSpider(scrapy.Spider):
    name = 'urlSpider'
    allowed_domains = ['exchange.xforce.ibmcloud.com']
    urls=['https://exchange.xforce.ibmcloud.com/api/whois/','https://exchange.xforce.ibmcloud.com/api/resolve/deep/','https://exchange.xforce.ibmcloud.com/api/ipr/malware/','https://exchange.xforce.ibmcloud.com/api/ipr/']
    headers1={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br',
            'x-ui': 'XFE',
            'Cache-Control': 'no-cache'
            }
    headers3={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate, br',
            'x-ui': 'XFE',
            'Cache-Control': 'no-cache'
    }
    headers2={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
            'x-ui': 'XFE'
            }
    cookie = settings['__cfduid=d78b2c640d21a978ec04d662c436eeab61537407759; BMAID=01d23723-703d-4810-bb51-f7b89a9a1af7; CoreID6=84504938228015374077499&ci=50200000|XFORCE; CoreM_State=15~-1~-1~-1~-1~3~3~5~3~3~7~7~|~~|~~|~~|~||||||~|~~|~~|~~|~~|~~|~~|~~|~; CoreM_State_Content=6~|~F94BF115D41891F6~D262BE0BA2F8BEB0~940DAE898C1D7DE1~E4F65E4DF1544BDB~A2994ECF23E54F73~D06F0501460ED32F~|~0~1~2~3~4~5; kampyle_userid=6106-bc74-97e0-ee1f-a356-ac27-eba9-d351; kampyleUserSession=1538036415202; kampyleSessionPageCounter=1; kampyleUserSessionsCount=13; cd_user_id=165f4a5daa6170-01e7ecf6120974-4c322f7c-144000-165f4a5daa7de; DECLINED_DATE=1537457729061; 50200000_clogin=l=32858641538193855237&v=1&e=1538196658581; CMAVID=none; connect.sid=s%3A1-JpeL5xW_xG8B_G8IIBOyMNO5BcS8a2.hasv0muJ1FqLeT8mV8W45CFq9sMhAruGonLcH%2BuRr%2BE; loggedInSession=1; cmTPSet=Y']
    start_urls = ['https://exchange.xforce.ibmcloud.com/api/']
    ipStrList=[]
    #basePath='./ipinfo/'
    basePath='./ipsInfo/'
    offset=0
    whoisData=""
    def start_requests(self):
        for line in open("test-ips.txt"):
            ipStr=(line.replace("\n",""))
            self.ipStrList.append(ipStr)

        url1=self.urls[0]+self.ipStrList[self.offset]
        yield scrapy.Request(url=url1,headers=self.headers3,cookies=self.cookie,callback=self.parse1)
        url2=self.urls[1]+self.ipStrList[self.offset]
        yield scrapy.Request(url=url2,headers=self.headers2,method="POST",callback=self.parse2)
        url3=self.urls[2]
        yield scrapy.Request(url=url3+self.ipStrList[self.offset],headers=self.headers1,callback=self.parse3)
        url4=self.urls[3]
        yield scrapy.Request(url=url4+self.ipStrList[self.offset],headers=self.headers1,callback=self.parse4)
###############################判断键字段是否存在#############################
    def checkKey(self,key,dictData):
        if key in dictData:
            if dictData[key]=={}:
                dictData[key]=""
                data=dictData[key]
            elif isinstance(dictData[key],dict)==True:
                for item in dictData[key]:
                    data=item
            else:
                data=dictData[key]
        else:
            dictData[key]=""
            data=dictData[key]
        return data
####################获取键值############################################
    def cKey(self,itemkey,data):
        #判断键
        if itemkey in data:
            jsondata=jsonpath.jsonpath(data,'$..'+itemkey)
            for key in jsondata:
                key=key
                if key=={}:
                    #如果第一层key值为{}输出为空
                    key=""
                #判断第二层key
                elif isinstance(key,dict)==True:
                    for item in key:
                        key=item
        else:
            #如果不存在键输出为空
            key=""
        return key
    def checkdata(self,itemkey,data):
        #判断键
        if itemkey in data:
            jsondata=jsonpath.jsonpath(data,'$.'+itemkey)
            for key in jsondata:
                key=key
                # #判断第二层key
                # elif isinstance(key,dict)==True:
                #     key=key
        else:
            #如果不存在键输出为空
            key=""
        return key
########################jsonpath处理#######################################
    def boolHandle(self,data):
        if data==False:
            value=""
        elif isinstance(data,list)==True:
            value=data[0]
        elif isinstance(data,str)==True:
            value=str(data)
            print(value)
        return value


        
##------------------------DNS------------------------------------------------
############################################################################
    def parse2(self, response):
         FullPath = self.basePath+self.ipStrList[self.offset]    
         if not os.path.exists(FullPath):
            os.makedirs(FullPath)
         print(self.urls[1]+self.ipStrList[self.offset])
         datas=json.loads(response.body)
         print(datas)
         item=DnsItem()
         itemjson=[]
         #print(datas)
         #count=int(datas[0]['total_rows'])
         item['ip']=self.ipStrList[self.offset]
         for data in datas:
             print(data)

             item['dns_name']=self.checkKey('value',data)
             item['dns_position']=self.checkKey('locations',data)
             # if 'cats' in data:
             #     for key in data['cats']:
             #        item['dns_category']=key
             item['dns_category']=self.cKey('cats',data)
             item['dns_type']=self.checkKey('recordType',data)
             item['dns_last']=self.checkKey('date',data)
             item['dns_first']=self.checkKey('first',data)
             yield item

##------------------whois-------------------------------
#######################################################
    def parse1(self,response):
        FullPath = self.basePath+self.ipStrList[self.offset]    
        if not os.path.exists(FullPath):
            os.makedirs(FullPath)
        datas=json.loads(response.body)
        print(datas)
        item=WhoisItem()
        item['ip']=self.ipStrList[self.offset]
        item['update_time']=self.checkKey('updatedDate',datas)
        #self.whoisData=self.checkKey('updatedDate',datas)
        item['register_name']=self.checkKey('registrarName',datas)
        item['register_mail']=self.checkKey('contactEmail',datas)
        data1=jsonpath.jsonpath(datas,"$..organization")
        org_data=self.boolHandle(data1)
        if org_data=="":
            item['register_org']=""
        else:
            item['register_org']=org_data[0]
        data2=jsonpath.jsonpath(datas,"$..country")
        position_data=self.boolHandle(data2)
        if position_data=="":
            item['register_position']=""
        else:
            item['register_position']=position_data[0]
        yield item
        print(self.urls[0]+self.ipStrList[self.offset])
        

##--------------------恶意软件-------------------------
######################################################
    def parse3(self,response):
        FullPath = self.basePath+self.ipStrList[self.offset]    
        if not os.path.exists(FullPath):
            os.makedirs(FullPath)
        datas=json.loads(response.body)
        item=MalwareItem()
        item['ip']=self.ipStrList[self.offset]
        itemjson=[]
        print(datas)

        datas=jsonpath.jsonpath(datas,"$.malware")
        for data in datas:
            print(data)
            if data==[]:
                item['domain']=""
                item['malware_ip']=""
                item['malware_name']=""
                item['malware_family']=""
                item['malware_md5']=""
                item['malware_record_first']=""
                item['malware_record_last']=""
                yield item
            else:
                for data in data:

                    item['domain']=self.boolHandle(jsonpath.jsonpath(data,'$..domain'))
                    print(jsonpath.jsonpath(data,'$..domain'))
                    item['malware_ip']=self.boolHandle(jsonpath.jsonpath(data,'$..ip'))
                    print(jsonpath.jsonpath(data,'$..ip'))
                    item['malware_name']=self.boolHandle(jsonpath.jsonpath(data,'$..filepath'))
                    print(jsonpath.jsonpath(data,'$..filepath'))
                    item['malware_family']=self.boolHandle(jsonpath.jsonpath(data,'$..family'))
                    print(jsonpath.jsonpath(data,'$..family'))
                    item['malware_md5']=self.boolHandle(jsonpath.jsonpath(data,'$..md5'))
                    print(jsonpath.jsonpath(data,'$..md5'))
                    item['malware_record_first']=self.boolHandle(jsonpath.jsonpath(data,'$..first'))
                    print(jsonpath.jsonpath(data,'$..first'))
                    item['malware_record_last']=self.boolHandle(jsonpath.jsonpath(data,'$..last'))
                    yield item

        print(self.urls[2]+self.ipStrList[self.offset])

##-------------------子网---------------------------
####################################################
    def parse4(self,response):
        FullPath = self.basePath+self.ipStrList[self.offset]    
        if not os.path.exists(FullPath):
            os.makedirs(FullPath)
        datas=json.loads(response.body)
        item=SubnetItem()
        lineitem=TimelineItem()
        ipitem=IpinfoItem()
        sublist_history=jsonpath.jsonpath(datas,'$.history.*')#时间线数据
        sublist_current=jsonpath.jsonpath(datas,'$.subnets.*')#当前subnets数据
        subdata=json.dumps(sublist_history)
        subdataCurrent=json.dumps(sublist_current)
        subdata=json.loads(subdata)#历史
        print(subdata)
        subdataCurrent=json.loads(subdataCurrent)#当前
        print(subdataCurrent)
        item['ip']=self.ipStrList[self.offset]
        lineitem['ip']=self.ipStrList[self.offset]
        lineitem['domain']=""
        ipitem['domain']=""
        for itemsubnet in subdata:
            #-----------------时间线-------------
            lineitem['timelines_subnetIp']=self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..ip'))
            print(self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..ip')))
            lineitem['timelines_createTime']=self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..created'))
            print(jsonpath.jsonpath(itemsubnet,'$..created'))
            lineitem['timelines_reason']=self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..reason'))
            print(self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..reason')))
            lineitem['timelines_position']=self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..country'))
            print(self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..country')))
            lineitem['timelines_asns']=self.boolHandle(jsonpath.jsonpath(itemsubnet,'$..Company'))
            print(jsonpath.jsonpath(itemsubnet,'$..Company'))

            yield lineitem 
            #----------------当前subnets---------------
        for itemdata in subdataCurrent:
            item['subnet_ip']=self.boolHandle(jsonpath.jsonpath(itemdata,'$..subnet'))
            item['subnet_createTime']=self.boolHandle(jsonpath.jsonpath(itemdata,'$..created'))
            item['subnet_reason']=self.boolHandle(jsonpath.jsonpath(itemdata,'$..reason'))
            item['subnet_position']=self.boolHandle(jsonpath.jsonpath(itemdata,'$..country'))
            item['subnet_asns']=self.boolHandle(jsonpath.jsonpath(itemdata,'$..Company'))
            yield item 
            #---------------ip信息---------------------
        ipitem['ip']=self.ipStrList[self.offset]
        ipitem['ip_country']=self.boolHandle(jsonpath.jsonpath(datas,'$..country'))
        ipitem['ip_score']=self.checkdata('score',datas)
        ipitem['ip_cats']=self.checkdata('cats',datas)
        ipitem['ip_reason']=self.checkdata('reason',datas)
        yield ipitem
        if self.offset<len(self.ipStrList)-1:
            self.offset +=1

            print(self.urls[3]+self.ipStrList[self.offset])
            #if while ():
            #do
            
            yield scrapy.Request(url=self.urls[0]+self.ipStrList[self.offset],headers=self.headers3,cookies=self.cookie,callback=self.parse1) 
            while os.path.isfile(self.basePath+self.ipStrList[self.offset]+"/"+"DNS.json")==False:
                yield scrapy.Request(url=self.urls[1]+self.ipStrList[self.offset],headers=self.headers2,method="POST",callback=self.parse2)
            #if os.path.isfile(self.basePath+self.ipStrList[self.offset]+"/"+"malware.json")==False:
            while os.path.isfile(self.basePath+self.ipStrList[self.offset]+"/"+"malware.json")==False:
                yield scrapy.Request(url=self.urls[2]+self.ipStrList[self.offset],headers=self.headers1,callback=self.parse3)
            while os.path.isfile(self.basePath+self.ipStrList[self.offset]+"/"+"subnet.json")==False:
                yield scrapy.Request(url=self.urls[3]+self.ipStrList[self.offset],headers=self.headers1,callback=self.parse4)

