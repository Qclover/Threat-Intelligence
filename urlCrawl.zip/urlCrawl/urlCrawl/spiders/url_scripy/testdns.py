import socket
domain='sanzhu.cn'
myaddr = socket.getaddrinfo(domain, 'http')
print(myaddr[0][4][0])