import json
import jsonpath
#datas={'malware': []}
#datas={'A':'aa','B':'bb','C':[{'D':'ddd'}]}
#datas={"createdDate":"2013-04-23T00:00:00.000Z","updatedDate":"2017-04-26T00:00:00.000Z","contactEmail":"intl-abuse@list.alibaba-inc.com","registrarName":"Administered by ARIN","netRange":"198.11.128.0 - 198.11.191.255","contact":[{"type":"registrant","organization":"Alibaba.com LLC","country":"United States"}],"extended":{"createdDate":"2013-04-23T00:00:00.000Z","updatedDate":"2017-04-26T00:00:00.000Z","contactEmail":"intl-abuse@list.alibaba-inc.com","registrarName":"Administered by ARIN","netRange":"198.11.128.0 - 198.11.191.255","contact":[{"type":"registrant","organization":"Alibaba.com LLC","country":"United States"}]}}
datas={'value': 'trustik.net', 'type': 'url', 'recordType': 'A', 'locations': {}, 'date': '2018-09-26T09:34:00Z', 'first': '2018-09-26T09:34:00Z', 'cats': {}, 'score': None}

data=datas

def aa(data1,data):
    valuekey=""
    if data1 in data:
    	jsondata=jsonpath.jsonpath(data,'$..'+data1)
    	for dictd in jsondata:
    		if dictd=={}:
    			valuekey='1'
	        for key in dictd:
	        	print(key)
	     #    	print(key)
	     #    	valuekey=key
		    # return valuekey
value=aa('cats') 
print(value)               
                #return valuekey
# print(data)
# if data==False:
#     value="1"
# else:
#     value=data
#     print(value)
# if value!="":
#     print(value[0])
# datas=jsonpath.jsonpath(datas,"$.malware")
# for data in datas:
# 	print(data)
# 	if data==[]:
# 		value='value is empty'
# 	# data1=jsonpath.jsonpath(data,"$..type")
# 	else:
# 		for data in data:
# 			data1=jsonpath.jsonpath(data,"$..type")
# 			print(data1)
# 			if data1==False:
# 				value=""
# 			else:
# 				value=data1
# 	print(value)
# for dictd in data1:
# 	print(dictd)
# 	for key in dictd:
# 		print(key)
# data1=str(data1)

# for item in data:
# 	if 'D' and 'E' in item:
# 		for key in item['D']:
# 			aa=key
# 			print(aa)
# 		print(item['E'])
# 	    #print item['D'].keys()