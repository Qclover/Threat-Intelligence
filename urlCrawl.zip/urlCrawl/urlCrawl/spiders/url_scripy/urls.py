import urlparse
for line in open('urls.txt'):
	url=line
	domain=urlparse.urlparse(url)
	domain1=domain.netloc
	print domain1
	with open('ipsList.txt','a+')as f:
		f.write(domain1)
	
 