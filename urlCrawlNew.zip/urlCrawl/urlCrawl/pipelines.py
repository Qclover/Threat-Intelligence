# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
from urlCrawl.items import WhoisItem
from urlCrawl.items import DnsItem
from urlCrawl.items import MalwareItem
from urlCrawl.items import SubnetItem
from urlCrawl.items import TimelineItem
from urlCrawl.items import IpinfoItem

class UrlcrawlPipeline(object):
	#filename=""
    # def __init__(self):
    #     self.filename=open("DNS.json","w")
    path='./ipsInfo/'
    # def process_item(self, item, spider):
    # 	ipdir=item['ip']
    # 	print(ipdir)
    # 	with open(self.path+ipdir+"/"+"DNS1.json","a+")as f:

    #         text=json.dumps(dict(item),ensure_ascii=False)+'\n'
    #         f.write(text)
    #         return item
    # # def close_spider(self,spider):
    #     self.filename.close()
    def process_item(self, item, spider):

        if isinstance(item,WhoisItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"whois.json","w",encoding='utf-8')as f:
                text1=json.dumps(dict(item),ensure_ascii=False)+'\n'
                f.write(text1)
        elif isinstance(item,DnsItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"DNS.json","a+",encoding='utf-8')as f:
                text2=json.dumps(dict(item),ensure_ascii=False)+'\n'
                text2=json.loads(text2)
                if text2['rdns_name']=="" and text2['rdns_position']=="" and text2['rdns_category']=="" and text2['rdns_first']=="":
                    pass
                else:
                    #print(text2)
                    text2=json.dumps(dict(item),ensure_ascii=False)+'\n'
                    f.write(text2)
        elif isinstance(item,MalwareItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"malware.json","a+",encoding='utf-8')as f:
                text3=json.dumps(dict(item),ensure_ascii=False)+'\n'
                f.write(text3)
        elif isinstance(item,SubnetItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"subnet.json","a+",encoding='utf-8')as f:
                text4=json.dumps(dict(item),ensure_ascii=False)+'\n'
                f.write(text4)
        elif isinstance(item,TimelineItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"timeline.json","a+",encoding='utf-8')as f:
                text5=json.dumps(dict(item),ensure_ascii=False)+'\n'
                f.write(text5)

        elif isinstance(item,IpinfoItem):
            ipdir=item['ip']
            with open(self.path+ipdir+"/"+"ipinfo.json","a+",encoding='utf-8')as f:
                text6=json.dumps(dict(item),ensure_ascii=False)+'\n'
                f.write(text6)