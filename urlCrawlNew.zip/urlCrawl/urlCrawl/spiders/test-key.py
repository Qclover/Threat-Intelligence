#coding:utf-8
import json
import jsonpath

#datas={'value': 'trustik.net', 'type': 'url', 'recordType': 'A', 'locations': {}, 'date': '2018-09-26T09:34:00Z', 'first': '2018-09-26T09:34:00Z', 'cats': {'AA':'aaaa'}, 'score': None}
#datas={"ip":"198.11.132.198","history":[{"created":"2013-04-24T06:27:00.000Z","reason":"区域因特网注册","geo":{"country":"美国","countrycode":"US"},"ip":"198.11.128.0/18","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","score":1,"cats":{}},{"created":"2015-11-07T03:48:00.000Z","reason":"在多个宿主上找到内容","geo":{"country":"美国","countrycode":"US"},"ip":"198.11.132.198/32","cats":{"恶意软件":57},"categoryDescriptions":{"恶意软件":"此目录包含了恶意网站或恶意软件托管网站的IP地址。"},"reasonDescription":"在此 IP 地址上托管的 Web 站点中至少有一个包含上述类别的内容。","score":5.7},{"created":"2015-11-07T11:04:00.000Z","reason":"在多个宿主上找到内容","geo":{"country":"美国","countrycode":"US"},"ip":"198.11.132.198/32","cats":{"恶意软件":43},"categoryDescriptions":{"恶意软件":"此目录包含了恶意网站或恶意软件托管网站的IP地址。"},"reasonDescription":"在此 IP 地址上托管的 Web 站点中至少有一个包含上述类别的内容。","score":4.3},{"created":"2015-11-12T09:49:00.000Z","reason":"在多个宿主上找到内容","geo":{"country":"美国","countrycode":"US"},"ip":"198.11.132.198/32","categoryDescriptions":{},"reasonDescription":"在此 IP 地址上托管的 Web 站点中至少有一个包含上述类别的内容。","score":1,"cats":{}},{"created":"2017-07-26T06:24:00.000Z","reason":"区域因特网注册","asns":{"45102":{"Company":"CNNIC-ALIBABA-CN-NET-AP Alibaba (China) Technology Co., Ltd.","cidr":22}},"geo":{"country":"美国","countrycode":"US"},"ip":"198.11.132.198/32","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","score":1,"cats":{}}],"subnets":[{"created":"2017-10-18T06:23:00.000Z","reason":"区域因特网注册","asns":{"45102":{"Company":"CNNIC-ALIBABA-CN-NET-AP Alibaba (China) Technology Co., Ltd.","cidr":18}},"geo":{"country":"美国","countrycode":"US"},"ip":"198.11.128.0","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","score":1,"cats":{},"subnet":"198.11.128.0/18"},{"created":"2017-08-13T06:22:00.000Z","reason":"区域因特网注册","ip":"198.11.132.0","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","score":1,"cats":{},"subnet":"198.11.132.0/22"},{"created":"2017-10-18T06:23:00.000Z","reason":"区域因特网注册","asns":{"45102":{"Company":"CNNIC-ALIBABA-CN-NET-AP Alibaba (China) Technology Co., Ltd.","cidr":24}},"ip":"198.11.132.0","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","score":1,"cats":{},"subnet":"198.11.132.0/24"}],"cats":{},"geo":{"country":"美国","countrycode":"US"},"score":1,"reason":"区域因特网注册","reasonDescription":"五家 RIR 之一宣布（新的）IP 位置映射。","categoryDescriptions":{},"tags":[]}
#datas=json.dumps(datas)
datas={"cats":{"匿名服务":43,"恶意软件":43,"僵尸网络命令和控制服务器":43},"geo":{"country":"美国","countrycode":"US","score":1},"score":4.3,"reason":"第三方订阅源","reasonDescription":"从第三方订阅源导入此数据。","categoryDescriptions":{"匿名服务":"此目录包含web代理的IP地址（那些允许用户匿名对其进行访问的）。此外，这样的IP地址，也可以直接用于匿名上网（例如，通过引入到浏览器的设置）。"},"tags":[]}
jsondata=jsonpath.jsonpath(datas,'$..country')
for key in jsondata:
	print(key)
	# for key in key:
	# 	print(key)
# 198.54.117.200
# 139.129.177.243
# 60.208.37.166
#print(jsondata)
#datas={"created":"2013-04-24T06:27:00.000Z","reason":"区域因特网注册","geo":{"country":"美国","countrycode":"US"},"ip":"198.11.128.0/18","categoryDescriptions":{},"reasonDescription":"五家 RIR 之一宣布 （新的）IP 位置映射。","score":1,"cats":{}}
# def aa(data1,data):
# 	#判断键
#     if data1 in data:
#     	jsondata=jsonpath.jsonpath(data,'$..'+data1)
#     	#print(jsondata)
#     	for key in jsondata:
#     		key=key
#     		if key=={}:
#     			#如果第一层key值为{}输出为空
#     			key="2"
#     		#判断第二层key
#     		elif isinstance(key,dict)==True:
#     			for item in key:
#     				key=item
#     				#print(key)
   
#     else:
#     	#如果不存在键输出为空
#     	key="1"
#     return key
# for dataitem in jsondata:
# 	position=jsonpath.jsonpath(dataitem,'$..subnet')
# 	#print(dataitem)
# 	print(type(position[0]))
# 	print(position)
# 	print(type(position))
	

