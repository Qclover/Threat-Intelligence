for line in open("ips.txt"):
	print(line)