# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


# class UrlcrawlItem(scrapy.Item):
    #-----------whois------------
class WhoisItem(scrapy.Item):
    ip=scrapy.Field()
    update_time=scrapy.Field()#更新时间
    register_name=scrapy.Field()#注册人
    register_mail=scrapy.Field()#注册邮箱
    register_org=scrapy.Field()#组成组织
    register_position=scrapy.Field()#注册人国家或地区
    other=scrapy.Field()#其他
    #-----------DNS--------------
class DnsItem(scrapy.Item):
    ip=scrapy.Field()
    dns_name=scrapy.Field() 
    dns_category=scrapy.Field()
    dns_type=scrapy.Field()
    dns_position=scrapy.Field()
    dns_last=scrapy.Field()
    dns_first=scrapy.Field()
    #-----------恶意软件---------
class MalwareItem(scrapy.Item):
    ip=scrapy.Field()
    domain=scrapy.Field()
    walware_ip=scrapy.Field()
    walware_name=scrapy.Field()
    walware_family=scrapy.Field()
    walware_md5=scrapy.Field()
    walware_record_first=scrapy.Field()
    walware_record_last=scrapy.Field()

    #-----------subnet----------
class SubnetItem(scrapy.Item):
    ip=scrapy.Field()
    domain=scrapy.Field()
    subnet_ip=scrapy.Field()
    subnet_createTime=scrapy.Field()
    subnet_reason=scrapy.Field()
    subnet_position=scrapy.Field()
    subnet_asns=scrapy.Field()
    #rdns_first=scrapy.Field()
class TimelineItem(scrapy.Item):
    ip=scrapy.Field()
    domain=scrapy.Field()
    timelines_createTime=scrapy.Field()
    timelines_position=scrapy.Field()
    timelines_subnetIp=scrapy.Field()
    timelines_reason=scrapy.Field()
    timelines_asns=scrapy.Field()
class IpinfoItem(scrapy.Item):
    ip=scrapy.Field()
    domain=scrapy.Field()
    ip_country=scrapy.Field()
    ip_score=scrapy.Field()
    ip_cats=scrapy.Field()#ip标签
    ip_reason=scrapy.Field()#ip来源





